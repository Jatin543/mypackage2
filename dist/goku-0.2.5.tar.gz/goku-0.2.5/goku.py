print('i m here for you MAN!!')

def appending_to_other(s):
	j=[]
	try:
		for i in range(0,99):
			j.append(s[i])
	except:
		pass
	return (j)
